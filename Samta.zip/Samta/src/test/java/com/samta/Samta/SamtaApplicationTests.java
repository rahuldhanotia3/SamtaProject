package com.samta.Samta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamtaApplicationTests {

	@Test
	void contextLoads() {
	}

}
